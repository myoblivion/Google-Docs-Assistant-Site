let overlayLock = false;
const observerConfig = { childList: true, subtree: true };

function createOverlay() {
  if (overlayLock) return;
  overlayLock = true;

  // Get all pages sorted by their top position
  const pages = Array.from(document.querySelectorAll(".kix-page-paginated:not(.processed)"));
  pages.sort((a, b) => {
    const aTop = parseInt(a.style.top) || 0;
    const bTop = parseInt(b.style.top) || 0;
    return aTop - bTop;
  });

  pages.forEach(page => {
    const canvas = page.querySelector("canvas");
    if (!canvas) return;

    const overlay = createOverlayElement(page, canvas);
    const svg = getOrCreateSVG(overlay);
    svg.innerHTML = "";

    // Extract lines within this page
    const lines = page.querySelectorAll('.kix-lineview');
    lines.forEach((line, lineIndex) => {
      const text = line.textContent.trim();
      if (!text) return;

      // Calculate position relative to the page
      const lineRect = line.getBoundingClientRect();
      const pageRect = page.getBoundingClientRect();
      const x = lineRect.left - pageRect.left;
      const y = lineRect.top - pageRect.top;

      // Create SVG elements
      const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
      group.setAttribute("role", "paragraph");

      const svgRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      svgRect.setAttribute("aria-label", text);
      svgRect.setAttribute("x", x);
      svgRect.setAttribute("y", y);
      svgRect.setAttribute("width", text.length * 7.5); // Approximate width
      svgRect.setAttribute("height", 17.6); // Approximate height
      svgRect.style.cssText = "fill:rgba(255,0,0,0.1);stroke:#ff0000;stroke-dasharray:2,2";

      group.appendChild(svgRect);
      svg.appendChild(group);
    });

    page.classList.add("processed");
  });

  overlayLock = false;
}

// Helper functions (keep createOverlayElement and getOrCreateSVG as before)

// Mutation Observer and init function remain mostly the same
const observer = new MutationObserver(() => {
  requestAnimationFrame(() => createOverlay());
});

function init() {
  observer.observe(document.body, observerConfig);
  requestAnimationFrame(() => createOverlay());
}

// Start initialization
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  setTimeout(init, 1500);
}