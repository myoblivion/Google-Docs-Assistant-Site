console.log("Background script loaded!");

// Existing auth logic.
chrome.runtime.onInstalled.addListener(() => {
  chrome.identity.getAuthToken({ interactive: true }, token => {
    if (token) {
      chrome.storage.local.set({ gtoken: token });
    }
  });
});

chrome.identity.onSignInChanged.addListener(() => {
  chrome.identity.getAuthToken({ interactive: true }, token => {
    if (token) {
      chrome.storage.local.set({ gtoken: token });
    }
  });
});

// Listen for messages from content.js.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background: Received message", message);

  if (message.action === 'checkText') {
    if (!message.text) {
      console.error("Background: 'text' field missing in message");
      sendResponse({ error: "Missing text" });
      return;
    }

    console.log(
      "Background: Processing text - Length:", message.text.length,
      "Content:", message.text.substring(0, 50) + "..."
    );

    fetch("https://api.languagetool.org/v2/check", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ text: message.text, language: "en-US" })
    })
      .then((response) => {
        console.log("Background: API response status:", response.status);
        return response.json();
      })
      .then((data) => {
        console.log("Background: API success, data:", data);
        sendResponse({ data });
      })
      .catch((error) => {
        console.error("Background: API error:", error);
        sendResponse({ error: error.message });
      });

    return true; // Keep the channel open for async response.

  } else if (message.action === 'updateDoc') {
    // Get the token using chrome.identity.
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (!token) {
        console.error("Background: No auth token available.");
        sendResponse({ error: "No auth token available." });
        return;
      }
      
      const { docId, errorText, suggestion } = message;
      // Extract suggestion text if suggestion is an object.
      const suggestionText = typeof suggestion === 'object' && suggestion.value ? suggestion.value : suggestion;
      
      const requests = [{
        replaceAllText: {
          containsText: {
            text: errorText,
            matchCase: true
          },
          replaceText: suggestionText
        }
      }];

      const body = JSON.stringify({ requests });
      console.log("Background: Request body:", body);

      fetch(`https://docs.googleapis.com/v1/documents/${docId}:batchUpdate`, {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json'
        },
        body: body
      })
      .then(response => {
        if (!response.ok) {
          return response.text().then(text => {
            throw new Error(`HTTP ${response.status}: ${text}`);
          });
        }
        return response.json();
      })
      .then(data => {
        console.log("Background: Google Docs updated:", data);
        sendResponse({ data });
      })
      .catch(error => {
        console.error("Background: Error updating Google Doc:", error);
        sendResponse({ error: error.message });
      });
    });
    return true; // Inform Chrome that sendResponse will be called asynchronously.
  }
});
