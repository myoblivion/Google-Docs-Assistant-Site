// force-html.js (Updated)
const WHITELISTED_ID = "npnbdojkgkbcdfdjlfdmplppdphlhhcf"; // ProWritingAid's ID

(function() {
  // Immediate injection before Docs loads
  window._docs_force_html_by_ext = WHITELISTED_ID;
  window._docs_annotate_canvas_by_ext = WHITELISTED_ID;
  
  // Backup method for Chrome extensions
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    document.documentElement.setAttribute('data-extension-id', WHITELISTED_ID);
  }
})();