const WHITELISTED_ID = "npnbdojkgkbcdfdjlfdmplppdphlhhcf"; // ProWritingAid's ID

// == Core Functions ==
async function init() {
  try {
    initCanvasFallback();
    setupObservers();
    // Removed undefined startContentSync()
    getRectData();    // kick off the first check
  } catch (error) {
    console.error("Initialization Error:", error);
  }
}

// == Canvas Fallback Functions ==
function initCanvasFallback() {
  injectCanvasFallbackStyles();
  setupCanvasTextSync();
  console.warn("Canvas Mode: Using limited functionality");
  
  // Add accessibility button
  const accButton = document.createElement('button');
  accButton.textContent = 'Enable Accessibility Mode';
  accButton.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 999999;
    padding: 10px 20px;
    background: #2196F3;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  `;
  accButton.onclick = enableScreenReaderFallback;
  document.body.appendChild(accButton);
}

// ======================================================================
//  Text Measurement Utilities
// ======================================================================
let measureSpan = null;
function getMeasureSpan() {
  if (!measureSpan) {
    measureSpan = document.createElement('span');
    measureSpan.style.position = 'absolute';
    measureSpan.style.visibility = 'hidden';
    measureSpan.style.whiteSpace = 'pre';
    document.body.appendChild(measureSpan);
  }
  return measureSpan;
}

/**
 * Measures the width of `text` in pixels given a font style.
 * Example font style: "400 14px Arial"
 */
function measureTextWidth(text, fontStyle) {
  const span = getMeasureSpan();
  span.style.font = fontStyle;
  span.textContent = text;
  return span.offsetWidth;
}

// Fallback to a default font style if not found on the element.
function getRectFontStyle(rect) {
  const fontAttr = rect.getAttribute('data-font-css');
  if (!fontAttr) {
    return "400 14px Arial";
  }
  return fontAttr.replace(/&quot;/g, '"');
}

// ======================================================================
//  Combined Function: Get Data and Send Text for Check
// ======================================================================
function getRectData() {
  const rectElements = Array.from(document.querySelectorAll("div svg g rect"));
  let cumulativeOffset = 0;

  const data = rectElements.map(rect => {
    const text = rect.getAttribute("aria-label") || "";
    const start = cumulativeOffset;
    const end = cumulativeOffset + text.length;
    cumulativeOffset = end + 1; // +1 for the newline separator

    const fontStyle = getRectFontStyle(rect);
    return { rect, text, start, end, fontStyle };
  });

  // If data exists, join the texts and send for checking.
  if (data.length > 0) {
    const textToSend = data.map(item => item.text).join("\n");
  
    if (textToSend) {
      chrome.runtime.sendMessage(
        { action: 'checkText', text: textToSend },
        (response) => {
          if (chrome.runtime.lastError) {
            return;
          }
          if (response?.data) {
            highlightErrors(response.data);
          } else {
            console.error("Error from background:", response?.error);
          }
        }
      );
    } else {
      console.log("No text to send, aborting.");
    }
  }
  return data;
}
console.log(getRectData());

// ======================================================================
//  Observers & Highlighting Logic
// ======================================================================
function setupObservers() {
  // Save an initial snapshot of the rect data.
  let previousData = getRectData();

  // Poll every 1000 milliseconds (adjust as needed)
  setInterval(() => {
    const newData = getRectData();

    // Check for changes in the length or content of the text on any rect.
    if (newData.length !== previousData.length) {
      console.log("detect changes: number of rects changed");
    } else {
      newData.forEach((newRect, index) => {
        const prevRect = previousData[index];
        if (newRect.text !== prevRect.text) {
          console.log("detect changes on rect:", newRect.rect);
          console.log("old value:", prevRect.text);
          console.log("new value:", newRect.text);
        }
      });
    }

    // Update the snapshot.
    previousData = newData;
  }, 1000);
}

/**
 * Display a popup with the error message and optional fix button.
 * @param {string} message - The error message to display.
 * @param {number} left - The left position (in pixels) for the popup.
 * @param {number} top - The top position (in pixels) for the popup.
 * @param {Array} [suggestions] - An array of suggested corrections.
 * @param {Object} errorContext - The context of the error (rect, original text, slice positions).
 */
function showErrorPopup(message, left, top, suggestions, errorContext) {
  // Remove any existing popup
  const existingPopup = document.querySelector('.lt-popup');
  if (existingPopup) {
    existingPopup.remove();
  }

  // Create the popup container
  const popup = document.createElement('div');
  popup.className = 'lt-popup';
  popup.style.position = 'absolute';
  popup.style.top = `${top}px`;
  popup.style.left = `${left}px`;
  popup.style.background = '#fff';
  popup.style.border = '1px solid #ccc';
  popup.style.padding = '10px';
  popup.style.borderRadius = '4px';
  popup.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.15)';
  popup.style.zIndex = '1000001';
  popup.style.maxWidth = '250px';
  popup.style.fontFamily = 'Arial, sans-serif';
  popup.style.fontSize = '13px';
  popup.style.color = '#333';

  // Create the message element
  const messageEl = document.createElement('div');
  messageEl.textContent = message || 'This is a highlighted error — click to see details.';
  popup.appendChild(messageEl);

  // If suggestions exist, add a fix button.
  if (suggestions && suggestions.length > 0) {
    const fixBtn = document.createElement('button');
    fixBtn.textContent = 'Fix';
    fixBtn.style.marginTop = '8px';
    fixBtn.style.marginRight = '8px';
    fixBtn.style.padding = '2px 6px';
    fixBtn.style.fontSize = '12px';
    fixBtn.style.cursor = 'pointer';
    fixBtn.style.border = 'none';
    fixBtn.style.background = '#4CAF50';
    fixBtn.style.color = '#fff';
    fixBtn.style.borderRadius = '3px';
    fixBtn.onclick = () => {
      // Apply the suggestion using the error context and update the actual Google Doc
      applyCorrection(suggestions[0], errorContext);
      popup.remove();
    };
    popup.appendChild(fixBtn);
  }

  // Create a close button
  const closeBtn = document.createElement('button');
  closeBtn.textContent = 'Close';
  closeBtn.style.marginTop = '8px';
  closeBtn.style.padding = '2px 6px';
  closeBtn.style.fontSize = '12px';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.border = 'none';
  closeBtn.style.background = '#2196F3';
  closeBtn.style.color = '#fff';
  closeBtn.style.borderRadius = '3px';
  closeBtn.onclick = () => popup.remove();
  popup.appendChild(closeBtn);

  // Append the popup to the document body
  document.body.appendChild(popup);
}

/**
 * Apply the suggested correction to the document.
 * This function uses the provided error context to replace the incorrect substring with the suggestion.
 * It updates both the canvas overlay (aria-label) and calls the Google Docs API to update the underlying text.
 * @param {string} suggestion - The correction suggestion to apply.
 * @param {Object} errorContext - Contains the target rect element, its original text, and the slice positions.
 */
function applyCorrection(suggestion, errorContext) {
  console.log("Applying correction:", suggestion);
  if (errorContext && errorContext.rect) {
    const { rect, originalText, sliceStart, sliceEnd } = errorContext;
    // Replace the erroneous substring with the suggestion in the canvas overlay.
    const newText = originalText.slice(0, sliceStart) + suggestion + originalText.slice(sliceEnd);
    rect.setAttribute('aria-label', newText);
    rect.classList.remove('lt-highlight');

    // Also update the underlying Google Doc via the Docs API.
    updateGoogleDocText(errorContext, suggestion);
  }
}

/**
 * Use the Google Docs API to update the document.
 * This demo uses the replaceAllText request to replace the erroneous text.
 * WARNING: replaceAllText may update multiple occurrences if the text is not unique.
 * In a production implementation, consider mapping the error's range more precisely.
 *
 * @param {Object} errorContext - The error context from the overlay.
 * @param {string} suggestion - The suggested correction.
 */
function updateGoogleDocText(errorContext, suggestion) {
  const errorText = errorContext.originalText.slice(errorContext.sliceStart, errorContext.sliceEnd);
  if (!errorText || !suggestion) {
    console.error("Invalid error text or suggestion.");
    return;
  }
  
  // Parse the document ID from the URL.
  const docIdMatch = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/);
  if (!docIdMatch) {
    console.error("Could not determine document ID.");
    return;
  }
  const docId = docIdMatch[1];

  const message = {
    action: 'updateDoc',
    docId,
    errorText,
    suggestion
  };

  chrome.runtime.sendMessage(message, (response) => {
    if (chrome.runtime.lastError) {
      console.error("Error sending message:", chrome.runtime.lastError);
      return;
    }
    console.log("Background update response:", response);
  });
}
/**
 * Highlight only the substring for each error from LanguageTool.
 */
function highlightErrors(apiResponse) {
  // Clear old highlights
  document.querySelectorAll('.lt-highlight').forEach(el => el.remove());

  const rectData = getRectData();
  if (!apiResponse.matches || !rectData.length) return;

  apiResponse.matches.forEach(match => {
    const start = match.offset;
    const end   = start + match.length;

    rectData.forEach(data => {
      if (start < data.end && end > data.start) {
        // Determine the slice of this rect to highlight.
        const sliceStart = Math.max(0, start - data.start);
        const sliceEnd   = Math.min(data.text.length, sliceStart + match.length);
        const errorText  = data.text.slice(sliceStart, sliceEnd);
        if (!errorText) return;

        // Capture context for later correction.
        const errorContext = {
          rect: data.rect,
          originalText: data.text,
          sliceStart,
          sliceEnd
        };

        // Measure text widths for accurate positioning.
        const prefix = data.text.slice(0, sliceStart);
        const xOffset = measureTextWidth(prefix, data.fontStyle);
        const w = measureTextWidth(errorText, data.fontStyle);

        // Get the rectangle's position on screen.
        const r = data.rect.getBoundingClientRect();
        const top  = r.top + r.height - 2; // 2px above the bottom.
        const left = r.left + xOffset;

        // Create the underline highlight element.
        const u = document.createElement('div');
        u.className = 'lt-highlight';
        u.style.position        = 'absolute';
        u.style.top             = `${top}px`;
        u.style.left            = `${left}px`;
        u.style.width           = `${w}px`;
        u.style.height          = `5px`;
        u.style.backgroundColor = 'red';
        u.style.zIndex          = '1000000';
        u.style.pointerEvents   = 'auto';
        u.style.cursor          = 'pointer';

        // Click handler: show the popup with error message and possible fix.
        u.addEventListener('click', e => {
          e.stopPropagation();
          // Pass the error context so that applyCorrection knows exactly what to update.
          showErrorPopup(match.message, left, top - 60, match.replacements, errorContext);
        });

        document.body.appendChild(u);
      }
    });
  });
}

// ======================================================================
//  Canvas Fallback Functions (continued)
// ======================================================================
function setupCanvasTextSync() {
  // Text extraction from aria-labels.
  setInterval(() => {
    const textContent = Array.from(document.querySelectorAll('[aria-label]'))
      .map(el => el.getAttribute('aria-label'))
      .filter(text => text && text.trim().length > 0)
      .join('\n');
      
    chrome.storage.local.set({ currentDocText: textContent });
  }, 2000);

  // Simulated click handling.
  document.addEventListener('click', handleCanvasClick);
}

function handleCanvasClick(e) {
  const canvasEl = document.elementFromPoint(e.clientX, e.clientY);
  if (canvasEl?.closest('.kix-canvas')) {
    const rect = canvasEl.getBoundingClientRect();
    chrome.runtime.sendMessage({
      action: 'canvasClick',
      position: {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      }
    });
  }
}

function enableScreenReaderFallback() {
  localStorage.setItem('docs-annotate-user-id', WHITELISTED_ID);
  localStorage.setItem('accessibilityMode', 'true');
  window.location.reload();
}

function injectCanvasFallbackStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .kix-canvas-tile-content rect {
      stroke-width: 5px !important;
      pointer-events: all !important;
    }
  `;
  document.head.appendChild(style);
}

// == Initialization ==
if (document.readyState === 'complete') {
  setTimeout(init, 500);
} else {
  document.addEventListener('DOMContentLoaded', init);
}
